# Sophia &mdash; personal AI assistant

Sophia is the assistant inside `assistant.html`. This page is a complete
rewrite of the old file: it keeps the same look, but one brain now runs both
the big console and the "Sophia (Discovery & Life Hub)" window, and it can
really control your Windows laptop when you start it the right way.

It is made for your laptop: Windows 10 Pro, Intel Core i3-4005U, 4 GB RAM,
1366 x 768. Nothing is installed, nothing is downloaded, and it works offline
except for the things that need the internet (websites, Wikipedia, voice).

---

## 1. What goes on the laptop

Sophia is five small files that sit together in one folder:

| File | What it is |
| --- | --- |
| `assistant.html` | Sophia herself. This is the page you open. |
| `sophia_helper.py` | A small helper that lets Sophia use Windows. |
| `Start_Sophia.bat` | Double-click this to start Sophia. |
| `INSTALL_SOPHIA.bat` | The one-step installer. |
| `Install_Sophia.ps1` | The script the installer runs. |

You do not need to place them by hand: **`INSTALL_SOPHIA.bat`** copies them to
the right folder, keeps a backup of the old page and makes a Desktop shortcut.
See section 8.

---

## 2. How to start her

**Best way (full control):** double-click **`Start_Sophia.bat`**.

A black window opens, then your browser opens Sophia. Keep the black window
open while you use her; close it when you are done. The address will be
`http://127.0.0.1:8765/assistant.html` and the tag at the top says
**Laptop control active**.

**Simple way (no Python):** double-click **`assistant.html`**.

The page opens straight from the file. Websites, the calculator, the camera,
Windows settings and your delivery app still work. Opening other apps,
changing the volume or brightness, closing apps and taking screenshots need
the helper, so Sophia will tell you to use `Start_Sophia.bat` instead of
pretending it worked.

If Windows shows a blue "Windows protected your PC" box for the `.bat` file:
click **More info** then **Run anyway**. The file is only a few lines of text
and you can open it in Notepad to read it.

### Do you have Python?

The helper needs Python 3. If `Start_Sophia.bat` says Python was not found,
install it once from <https://www.python.org/downloads/windows/> and tick
**Add python.exe to PATH** during setup. Then double-click the `.bat` again.
Without Python everything except laptop control still works.

---

## 3. What Sophia can do

**Open things**

```
open youtube                    open notepad
open gmail and github           open chrome and spotify
open github.com                 open my downloads folder
open wifi settings              open delivery app
```

**Search and play**

```
search youtube for lofi music   google the capital of France
play arijit singh songs         search gmail for exam
show me pictures of cats        latest news about isro
weather in patna
```

**Control the laptop** (needs `Start_Sophia.bat`)

```
volume up                       set volume to 40        mute
brightness down                 set brightness to 60    dim the screen
next song                       pause the music
take a screenshot               lock my laptop
shut down the laptop            restart                 sleep
```

Sophia always asks **"Say yes to confirm"** before shutting down, restarting,
sleeping or signing out, and she never lets an AI model do those things.

**Remember things**

```
remember that my bag is in the cupboard
where is my bag
my exam is on monday            when is my exam
remember that my favourite colour is blue
what do you remember            forget my bag
```

Memory is saved in this browser on this laptop only.

**Teach her shortcuts**

```
when I say study time open youtube and gmail
study time
what are my shortcuts
```

**Ask things**

```
what time is it                 what is the date
what is 25 times 4              calculate 15% of 250
how much ram                    laptop specs
who is APJ Abdul Kalam          what is photosynthesis
tell me a joke                  i am bored
```

**Talk, in English or Hindi-English**

```
hi                              how are you
i am sad                        i am hungry
youtube kholo                   instagram kholo
volume badhao                   awaaz kam karo
time kya hai                    mera naam kya hai
screenshot lo                   shukriya
```

**Type or speak.** Everything works both ways: the text box, the orb, the
microphone button and the 8 launcher buttons all use the same brain.

---

## 3b. Feelings and knowledge (new in this version)

**Talking about feelings.** Sophia reads the *words* you use and answers
gently. She is not a doctor and she cannot see your face or hear your voice
tone, so this is pattern matching, not mind reading. Say any of these:

```
i am sad                     i feel lonely
i am stressed about my exam  my parents are fighting
i am angry at my friend      i cannot sleep
i feel like a failure        i miss my grandmother
nobody talks to me at school i am so tired of everything
i am happy today             i topped my class
i am hungry                  i have a headache
```

She answers with one short, kind line, then usually asks **one** question or
offers **one** small step, such as a breathing round, a glass of water, or
"tell a parent". She does not lecture and she does not pretend to be a person.

Some things get a different answer on purpose:

- If you say something like **"i want to die"** or you are hurting yourself,
  Sophia stops being a chatbot and asks you to talk to a real adult **today**.
  She gives the free Indian helplines: **Tele-MANAS 14416**, **Childline 1098**
  and **112** if you are in danger.
- If someone is hurting you, she tells you it is not your fault and asks you to
  tell one adult you trust, and to keep the messages or screenshots as proof.
- She says clearly that she is an AI program, so she is not a replacement for a
  parent, a teacher or a counsellor.

**How your week looked.** Tap a face in the *How are you feeling right now?*
card (or in the Sophia Hub). The little bars under it show the last dozen
feelings, and **Settings > How your week has felt** shows a simple count.
Everything stays in this browser on this laptop. **Forget my feelings** clears
it. Sophia uses that history only to be a little gentler, for example asking
about sleep if you have been tired lately.

**Knowledge without internet.** She carries her own notes so she can still
answer when the Wi-Fi is down. Right now that is:

- **30 topics** with about **190 honest notes**, for example the solar system,
  photosynthesis, the human body, the water cycle, atoms, electricity,
  computers, AI, India, Indian history, India's freedom fighters, world
  history, world geography, maths, English, languages, animals, earthquakes,
  matter and forces, health, sports, inventions, space missions, the
  environment, money, coding and how the body works.
- **60 quick facts** ("tell me a fact" gives a new one each time).
- **12 riddles** with hints.
- **96 quiz questions**, five per round, with a score and a streak.
- **60+ country capitals**, unit conversion (km/miles, kg/pounds, cm/inches,
  litres/ml, Celsius/Fahrenheit) and averages.

Try:

```
tell me about the solar system     quiz me on space
tell me a fact                     tell me a riddle
capital of australia               convert 10 km to miles
average of 12 18 25                my laptop is hanging
play a game                        play word chain
```

If she does not know, she says so, then offers Wikipedia, then Google. She
never invents a fact to look clever. When she answers from her own notes she
says so, so you always know where an answer came from.

---

## 4. The voice button

Voice input uses your browser's speech recognition, so it needs the internet
and works best in **Chrome or Edge**. The first time you click the orb, the
browser asks for microphone permission; click **Allow**.

If you see "Microphone blocked", click the small padlock in the address bar,
allow the microphone, then reload the page.

Sophia stops listening while she is speaking, so she never hears herself and
answers her own sentence.

---

## 5. Settings (the gear button)

* **Your name** &mdash; what she should call you.
* **Speak replies out loud** and **voice language** (English India, UK, US,
  Hindi).
* **AI model for open questions** &mdash; this is optional:

| Choice | What it means |
| --- | --- |
| Built-in brain only | Works with no account and no internet. Handles all commands, maths, memory, time, and small talk. Unknown facts are looked up on Wikipedia. |
| Google Gemini | Free key from <https://aistudio.google.com>. Ask a parent first. |
| OpenAI-compatible | Any service with an API key (OpenAI, Groq, OpenRouter, a local Ollama). |

When a model is connected, Sophia gets much better at open questions and can
explain things in her own words. The privacy tag in her window changes to say
that questions go to that service. Your key is stored only in this browser.

The model can also ask Sophia to **open** things while she answers (for
example "open youtube and play lofi"), but it can never shut down or restart
the laptop.

---

## 6. Is it safe?

* The helper listens on **127.0.0.1 only**, which means only this laptop can
  talk to it. Other computers on your Wi-Fi cannot reach it.
* It refuses requests that come from other websites, and each page load gets a
  fresh secret token.
* It only runs a fixed list of actions. It cannot open `file://` links, run
  commands, or delete files.
* It can never close Explorer, Task Manager, your browser, `cmd`, PowerShell
  or Sophia herself.
* It never force-closes an app; if a program will not close politely, Sophia
  says so and asks you to close it.
* Nothing is sent anywhere by default.

---

## 7. If something goes wrong

| Problem | What to do |
| --- | --- |
| "Could not start Sophia on 127.0.0.1:8765" | She is probably already running. Look for the black window, or just open `http://127.0.0.1:8765/assistant.html`. |
| The tag says **Browser mode** | You opened `assistant.html` directly. Use `Start_Sophia.bat` for full control. |
| Nothing happens when she opens a site | The browser blocked the new tab. Click the blue link she gives you, or allow pop-ups for this page. |
| "I cannot find index.html" | Copy your delivery app's `index.html` into the same folder as `assistant.html`. |
| No sound from the microphone | Allow the microphone (padlock icon), and check Windows Settings &rarr; Privacy &rarr; Microphone. |
| She says "this screen does not let Windows change its brightness" | Some laptop screens (and many external monitors) block brightness control. Use the keyboard brightness keys. |
| An app will not open | Sophia looks in the Start Menu and in the Microsoft Store. If it still fails, pin it to Start or tell me the exact name. |

---

## 8. Putting Sophia on the laptop (one step)

I cannot reach your laptop from here: nothing on my side can open your folders
or install anything for you. So the download installs itself.

1. Download `Sophia-Updated.zip` from GitHub and unzip it.
2. Double-click **`INSTALL_SOPHIA.bat`** inside the unzipped folder.
3. It finds your delivery app folder, asks once to confirm, then:
   * copies `assistant.html`, `sophia_helper.py` and `Start_Sophia.bat`,
   * keeps your old page as `assistant-old-<date>.html`,
   * puts a **Sophia** shortcut on your Desktop,
   * offers to start her straight away.

If Windows shows "Windows protected your PC", click **More info** then
**Run anyway**; that box appears for every downloaded file. You can also
right-click `Install_Sophia.ps1` and choose **Run with PowerShell**.

To undo everything: rename `assistant-old-<date>.html` back to
`assistant.html`. Nothing else on the laptop is touched.

---

## 9. Files in this repository

| File | Purpose |
| --- | --- |
| `assistant.html` | Sophia: the brain, the page, the look. One file, no build step. |
| `sophia_helper.py` | Local Windows helper and tiny web server (Python standard library only). |
| `Start_Sophia.bat` | Double-click starter. Finds Python, then opens Sophia. |
| `INSTALL_SOPHIA.bat` | One-step installer: copies the files and makes a Desktop shortcut. |
| `Install_Sophia.ps1` | The PowerShell script behind the installer. |
| `tests/brain.test.js` | 38 tests for what Sophia understands. `node --test tests/brain.test.js` |
| `tests/test_helper.py` | 37 tests for the helper, the installer and the server. `python3 -m unittest discover tests` |

Old versions: `git show 09ca826:assistant.html` is the file exactly as you
first uploaded it.

---

## 10. Honest limits

* Sophia is a program, not a person. She has no feelings, no body, and she
  cannot really "think" like a human. The "human intelligence" part is a
  carefully written set of rules (her brain) plus, if you connect one, an AI
  language model. That is how every assistant works.
* She understands the commands in this guide well. Ask her something far away
  from those patterns and she will use Wikipedia, the AI model if you
  connected one, or offer a Google search.
* Her feeling reader is **text only**. She reads the words you type or dictate,
  not your face, your voice tone, or your heartbeat, and she does not diagnose
  anything. If something feels really heavy, a real adult is always better than
  a program, and she says so.
* Her offline knowledge is a fixed set of notes (30 topics, about 190 notes).
  It is real, checked-by-hand information, but it is not the whole internet.
  Anything outside it goes to Wikipedia, then a Google search.
* Timers, reminders, weather readings inside the app, and controlling other
  phones or printers are not built yet.
* A real AI key needs an adult's account and may cost money. Ask a parent.
* Windows-only for laptop control. On a Mac or Linux the helper runs in
  preview mode only.

---

Made for Kartikey Raj. If you want a new command, just tell me what you would
type, and I will add it.
